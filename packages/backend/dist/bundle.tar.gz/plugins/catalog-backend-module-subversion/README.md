# @internal/plugin-catalog-backend-module-subversion

The subversion backend module for the catalog plugin.

_This plugin was created through the Backstage CLI_
